package com.itheima.core.dao;
import java.util.List;
import com.itheima.core.po.Customer;
/**
 * Customer接口
 */
public interface CustomerDao {
    // 客户列表
	public List<Customer> selectCustomerList(Customer customer);
	// 客户数
	public Integer selectCustomerListCount(Customer customer);
	
	// 客户列表
		public List<Customer> selectCustomerList2(Customer customer);
		// 客户数
		public Integer selectCustomerListCount2(Customer customer);
		
		// 客户列表
				public List<Customer> selectCustomerListreduce(Customer customer);
				// 客户数
				public Integer selectCustomerListCountreduce(Customer customer);
	
	
	// 创建客户
	public int createCustomer(Customer customer);
	public int createCustomer2(Customer customer);
	public int createCustomerreduce(Customer customer);
	// 通过id查询客户
	public Customer getCustomerById(Integer id);
	public Customer getCustomerById2(Integer id);
	public Customer getCustomerByIdreduce(Integer id);
	// 通过name查询客户
		public Customer getCustomerByName(String name);
	
	// 更新客户信息
	public int updateCustomer(Customer customer);
	public int updateCustomer2(Customer customer);
	// 删除客户
	int deleteCustomer (Integer id);
	int deleteCustomer2 (Integer id);
	int deleteCustomerreduce (Integer id);
	
	

}
