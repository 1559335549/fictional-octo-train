package com.itheima.core.service;
import com.itheima.common.utils.Page;
import com.itheima.core.po.Customer;
public interface CustomerService {
	// 查询客户列表
	public Page<Customer> findCustomerList(Integer page, Integer rows, 
                                        String custName,String custSource,
                                        String custIndustry,String custLevel);
	
	public int createCustomer(Customer customer);
	public int createCustomer2(Customer customer);
	public int createCustomerreduce(Customer customer);
	
	// 通过id查询客户
	public Customer getCustomerById(Integer id);
	public Customer getCustomerById2(Integer id);
	public Customer getCustomerByIdreduce(Integer id);
	// 通过name查询客户
		public Customer getCustomerByName(String name);
	// 更新客户
	public int updateCustomer(Customer customer);
	// 更新客户2
	public int updateCustomer2(Customer customer);
	// 删除客户
	public int deleteCustomer(Integer id);
	
	
	
	public Page<Customer> findCustomerList2(Integer page, Integer rows, 
            String custName,String custSource,
            String custIndustry,String custLevel);
	
	public int deleteCustomer2(Integer id);
	public int deleteCustomerreduce(Integer id);
	public Page<Customer> findCustomerListreduce(Integer page, Integer rows, 
            String custName,String custSource,
            String custIndustry,String custLevel);
	

}
